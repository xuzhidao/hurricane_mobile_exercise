# Preparation

1. clone this empty project into your local
2. set up the project.
3. use the interfaces we provided to showing the information.

API:

article: https://interface.meiriyiwen.com/article/day?dev=1&date=${date(formate like 20170216)}

weather: https://weatherstack.com/documentation

```
  https://api.weatherstack.com/historical
    ? access_key = YOUR_ACCESS_KEY
    & query = New York
    & historical_date = 2015-01-21
    & hourly = 1
```

# Requirement

We want a app that we can search the weather with specific city and date.

Need 2 screens, **SearchView screen** and **DetailView screen**

in the SearchView screen, we need 2 input box, one for city, one for date.

in the DetailView screen, we need to display incluing weather in the top & article in the bottom, detail weather information like the image, city, temperature and so on...
For the article, just display after the weather information.
you can check the screenshot/Layout.png, it is a simple demo layout.


# technical requirement

follow the structure we difined in the project, use Objective-c + Swift.

If you only have experience for OC/swift one of them, pls specify to us and create a new project.

we also need unit test case

time: 6 hours

Good Luck