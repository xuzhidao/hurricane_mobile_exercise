package com.android.checking.ui.screen

class DetailViewScreen {
}