package com.android.checking.ui.screen

import androidx.compose.material.Text
import androidx.compose.runtime.Composable

@Composable
fun SearchViewScreen(name: String) {
    Text(text = "Hello $name!") //example code, please remove it.
}