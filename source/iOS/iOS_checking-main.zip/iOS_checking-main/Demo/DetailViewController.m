//
//  DetailViewController.m
//  Demo
//
//

/**
    Requirement:
        
        show user info & login type in this page
        also the user picture
 
 */


#import "DetailViewController.h"

@implementation DetailViewController

@end
