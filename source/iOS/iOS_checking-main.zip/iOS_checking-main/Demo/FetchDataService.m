//
//  FetchDataService.m
//  Demo
//
//


/**
    Requirement:
        
    use the mockResp.json to create a mock sever, use AFNewtwork to get the response
    make the service as singleton
 
    keep the password in device to perform the touch/face ID login.
 
 */


#import "FetchDataService.h"

@implementation FetchDataService

@end
