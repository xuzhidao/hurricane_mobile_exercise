//
//  DemoObj.swift
//  Demo
//
//

/**
    Requirement:
        use Codable make this object as the mockResp entity.
 */

import Foundation
