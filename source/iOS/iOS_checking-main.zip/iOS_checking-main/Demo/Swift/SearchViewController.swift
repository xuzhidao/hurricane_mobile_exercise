//
//  SearchViewController.swift
//  Demo
//
//

/**
 
 Requirement:
        
    use delegate
 
    check the user input, if pass, then go into UserDetailViewController
 
    use touchID or FaceID after first login done.
 
    user input real-time verification
        
 */


import Foundation
