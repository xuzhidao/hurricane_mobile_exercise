# Preparation

1. clone this empty project into your local
2. set up the project with cocoapods.
3. use the interfaces we provided to showing the information.

API:

article: https://interface.meiriyiwen.com/article/day?dev=1&date=${date(formate like 20170216)}
weather: https://weatherstack.com/documentation
# Requirement

We want a app that we can search the weather with specific city and date.

Need 2 screens, **SearchViewController** and **DetailViewController**

in the SearchViewController, we need 2 input box, one for city, one for date.

in the DetailViewController, we need to display incluing weather in the top & article in the bottom, detail weather information like the image, city, temperature and so on...
For the article, just display after the weather information.


# technical requirement

follow the structure we difined in the project, use Objective-c + Swift.

If you only have experience for OC/swift one of them, pls specify to us and create a new project.

we also need unit test case

time: 6 hours

Good Luck


